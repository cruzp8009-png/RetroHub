#!/usr/bin/env python3
"""Deterministic Xcode project generator; no XcodeGen/CocoaPods dependency."""
from pathlib import Path
import hashlib, json, plistlib, struct, zlib
ROOT = Path(__file__).resolve().parents[1]
def oid(name): return hashlib.sha1(name.encode()).hexdigest()[:24].upper()
def quote(value): return json.dumps(str(value))
objects = {}
def add(name, fields): objects[oid(name)] = fields; return oid(name)
def array(values): return '( ' + ', '.join(values) + ', )' if values else '()'
files = sorted([*ROOT.glob('App/*.swift'), *ROOT.glob('Sources/RetroHubCore/*.swift')])
builds, refs = [], []
for file in files:
    relative = file.relative_to(ROOT).as_posix()
    ref = add('file:'+relative, f'isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = {quote(relative)}; sourceTree = SOURCE_ROOT;')
    refs.append(ref); builds.append(add('build:'+relative, f'isa = PBXBuildFile; fileRef = {ref};'))
plist_ref = add('plist', 'isa = PBXFileReference; lastKnownFileType = text.plist.xml; path = App/Info.plist; sourceTree = SOURCE_ROOT;')
assets_ref = add('assets', 'isa = PBXFileReference; lastKnownFileType = folder.assetcatalog; path = App/Assets.xcassets; sourceTree = SOURCE_ROOT;')
assets_build = add('assets-build', f'isa = PBXBuildFile; fileRef = {assets_ref};')
product = add('product', 'isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = RetroHub.app; sourceTree = BUILT_PRODUCTS_DIR;')
products = add('products', f'isa = PBXGroup; children = {array([product])}; name = Products; sourceTree = "<group>";')
group = add('group', f'isa = PBXGroup; children = {array(refs+[plist_ref,assets_ref,products])}; sourceTree = "<group>";')
sources = add('sources', f'isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = {array(builds)}; runOnlyForDeploymentPostprocessing = 0;')
resources = add('resources', f'isa = PBXResourcesBuildPhase; buildActionMask = 2147483647; files = {array([assets_build])}; runOnlyForDeploymentPostprocessing = 0;')
frameworks = add('frameworks', 'isa = PBXFrameworksBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;')
configs = {}
for owner in ['project','target']:
    ids = []
    for mode in ['Debug','Release']:
        settings = {'SDKROOT':'iphoneos','IPHONEOS_DEPLOYMENT_TARGET':'14.0','SWIFT_VERSION':'5.0','CLANG_ENABLE_MODULES':'YES','SWIFT_OPTIMIZATION_LEVEL':'-Onone' if mode=='Debug' else '-O','DEBUG_INFORMATION_FORMAT':'dwarf' if mode=='Debug' else 'dwarf-with-dsym'}
        if owner == 'target':
            settings.update({'PRODUCT_BUNDLE_IDENTIFIER':'org.retrohub.launcher','PRODUCT_NAME':'$(TARGET_NAME)','INFOPLIST_FILE':'App/Info.plist','TARGETED_DEVICE_FAMILY':'1,2','CODE_SIGN_STYLE':'Automatic','ASSETCATALOG_COMPILER_APPICON_NAME':'AppIcon','SUPPORTED_PLATFORMS':'iphoneos iphonesimulator','SUPPORTS_MACCATALYST':'NO','SWIFT_EMIT_LOC_STRINGS':'YES','CURRENT_PROJECT_VERSION':'1','MARKETING_VERSION':'1.0'})
        else:
            settings.update({'GCC_WARN_64_TO_32_BIT_CONVERSION':'YES','CLANG_WARN_DOCUMENTATION_COMMENTS':'YES'})
        if mode == 'Debug': settings['SWIFT_ACTIVE_COMPILATION_CONDITIONS']='DEBUG'
        fields = ' '.join(f'{key} = {quote(value)};' for key,value in settings.items())
        ids.append(add(owner+mode, f'isa = XCBuildConfiguration; buildSettings = {{ {fields} }}; name = {mode};'))
    configs[owner] = add(owner+'configs', f'isa = XCConfigurationList; buildConfigurations = {array(ids)}; defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;')
target = add('target', f'isa = PBXNativeTarget; buildConfigurationList = {configs["target"]}; buildPhases = {array([sources,frameworks,resources])}; buildRules = (); dependencies = (); name = RetroHub; productName = RetroHub; productReference = {product}; productType = "com.apple.product-type.application";')
project = add('project', f'isa = PBXProject; attributes = {{ LastUpgradeCheck = 1600; }}; buildConfigurationList = {configs["project"]}; compatibilityVersion = "Xcode 14.0"; developmentRegion = en; hasScannedForEncodings = 0; knownRegions = (en, Base); mainGroup = {group}; productRefGroup = {products}; projectDirPath = ""; projectRoot = ""; targets = {array([target])};')
project_dir = ROOT/'RetroHub.xcodeproj'; project_dir.mkdir(exist_ok=True)
(project_dir/'project.pbxproj').write_text('// !$*UTF8*$!\n{ archiveVersion = 1; classes = {}; objectVersion = 56; objects = {\n'+ '\n'.join(f'{key} = {{ {value} }};' for key,value in sorted(objects.items())) + f'\n}}; rootObject = {project}; }}\n')
scheme_dir = project_dir/'xcshareddata/xcschemes'; scheme_dir.mkdir(parents=True,exist_ok=True)
ref=f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="RetroHub.app" BlueprintName="RetroHub" ReferencedContainer="container:RetroHub.xcodeproj"/>'
(scheme_dir/'RetroHub.xcscheme').write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3">
<BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">{ref}</BuildActionEntry></BuildActionEntries></BuildAction>
<TestAction buildConfiguration="Debug" shouldUseLaunchSchemeArgsEnv="YES"><Testables/></TestAction>
<LaunchAction buildConfiguration="Debug" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0">{ref}</BuildableProductRunnable></LaunchAction>
<ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" useCustomWorkingDirectory="NO"><BuildableProductRunnable runnableDebuggingMode="0">{ref}</BuildableProductRunnable></ProfileAction>
<AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>''')
info = {'CFBundleDevelopmentRegion':'en','CFBundleDisplayName':'RetroHub','CFBundleExecutable':'$(EXECUTABLE_NAME)','CFBundleIdentifier':'$(PRODUCT_BUNDLE_IDENTIFIER)','CFBundleInfoDictionaryVersion':'6.0','CFBundleName':'$(PRODUCT_NAME)','CFBundlePackageType':'APPL','CFBundleShortVersionString':'1.0','CFBundleVersion':'1','LSRequiresIPhoneOS':True,'MinimumOSVersion':'14.0','UIRequiredDeviceCapabilities':['arm64'],'LSApplicationQueriesSchemes':['retroarch','delta','ppsspp'],'UIFileSharingEnabled':True,'LSSupportsOpeningDocumentsInPlace':True,'UILaunchScreen':{},'UISupportedInterfaceOrientations':['UIInterfaceOrientationPortrait'],'UISupportedInterfaceOrientations~ipad':['UIInterfaceOrientationPortrait','UIInterfaceOrientationPortraitUpsideDown','UIInterfaceOrientationLandscapeLeft','UIInterfaceOrientationLandscapeRight']}
extensions = ['nes','sfc','smc','gb','gbc','gba','n64','z64','v64','nds','cue','chd','pbp','iso','cso','md','gen','smd','zip','7z','bin']
types=[]
for ext in extensions:
    types.append({'UTTypeIdentifier':'org.retrohub.game.'+ext,'UTTypeDescription':ext.upper()+' game file','UTTypeConformsTo':['public.data'],'UTTypeTagSpecification':{'public.filename-extension':[ext]}})
info['UTImportedTypeDeclarations']=types
info['CFBundleDocumentTypes']=[{'CFBundleTypeName':'RetroHub game files','CFBundleTypeRole':'Viewer','LSHandlerRank':'Alternate','LSItemContentTypes':[x['UTTypeIdentifier'] for x in types]+['public.data']}]
(ROOT/'App/Info.plist').write_bytes(plistlib.dumps(info))
# Original procedural console icon: no downloaded or third-party art.
assets=ROOT/'App/Assets.xcassets'; icons=assets/'AppIcon.appiconset'; icons.mkdir(parents=True,exist_ok=True)
(assets/'Contents.json').write_text(json.dumps({'info':{'author':'RetroHub','version':1}}))
def png(size):
    rows=[]
    for y in range(size):
        row=bytearray()
        for x in range(size):
            u=x/size; v=y/size; color=(12,16,26)
            if .16<u<.84 and .25<v<.72: color=(40,53,72)
            if .20<u<.80 and .29<v<.68: color=(21,31,43)
            if (.31<u<.38 and .39<v<.59) or (.245<u<.445 and .455<v<.525): color=(94,242,194)
            if (u-.68)**2+(v-.44)**2<.034**2 or (u-.60)**2+(v-.55)**2<.034**2: color=(94,242,194)
            if .45<u<.55 and .76<v<.785: color=(94,242,194)
            row.extend(color)
        rows.append(b'\x00'+bytes(row))
    def chunk(t,d): return struct.pack('>I',len(d))+t+d+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',size,size,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(b''.join(rows),9))+chunk(b'IEND',b'')
images=[]
for idiom,specs in [('iphone',[(20,2),(20,3),(29,2),(29,3),(40,2),(40,3),(60,2),(60,3)]),('ipad',[(20,1),(20,2),(29,1),(29,2),(40,1),(40,2),(76,1),(76,2),(83.5,2)]),('ios-marketing',[(1024,1)])]:
    for points,scale in specs:
        pixels=int(points*scale); name=f'icon-{pixels}.png'; (icons/name).write_bytes(png(pixels))
        size=f'{points:g}x{points:g}'; images.append({'idiom':idiom,'size':size,'scale':f'{scale}x','filename':name})
(icons/'Contents.json').write_text(json.dumps({'images':images,'info':{'author':'RetroHub','version':1}},indent=2)+'\n')
print('Generated RetroHub.xcodeproj, Info.plist and original app icons.')
