#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v xcodebuild >/dev/null; then
  echo 'Xcode on macOS is required. No IPA was built.' >&2
  exit 1
fi
PROJECT_ROOT="$PWD"
mkdir -p build
swift test 2>&1 | tee build/swift-tests.log
xcodebuild -project RetroHub.xcodeproj -scheme RetroHub -configuration Release \
  -destination 'generic/platform=iOS' -archivePath build/RetroHub.xcarchive \
  archive CODE_SIGNING_ALLOWED=NO 2>&1 | tee build/archive.log
APP='build/RetroHub.xcarchive/Products/Applications/RetroHub.app'
# Public ad-hoc signature only. No provisioning, private entitlements or device changes.
codesign --force --sign - --timestamp=none "$APP"
codesign --verify --strict "$APP"
STAGING="$(mktemp -d "$PWD/build/ipa.XXXXXX")"
trap 'rm -rf "$STAGING"' EXIT
mkdir -p "$STAGING/Payload"
ditto "$APP" "$STAGING/Payload/RetroHub.app"
(cd "$STAGING" && zip -qr "$PROJECT_ROOT/build/RetroHub.ipa" Payload)
echo 'Built build/RetroHub.ipa (ad-hoc signature; intended for a compatible TrollStore installer, not normal stock-iOS installation).'
