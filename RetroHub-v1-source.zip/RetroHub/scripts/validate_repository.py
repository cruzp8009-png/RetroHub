#!/usr/bin/env python3
"""Structural checks only. This does not compile or substitute for Swift tests."""
from pathlib import Path
import json, plistlib, re, xml.etree.ElementTree as ET
root = Path(__file__).resolve().parents[1]
info = plistlib.loads((root/'App/Info.plist').read_bytes())
assert info['MinimumOSVersion'] == '14.0'
assert set(info['LSApplicationQueriesSchemes']) == {'retroarch','delta','ppsspp'}
assert info['UIFileSharingEnabled'] and info['LSSupportsOpeningDocumentsInPlace']
project = (root/'RetroHub.xcodeproj/project.pbxproj').read_text()
ids = re.findall(r'^([A-F0-9]{24}) =', project, re.M)
assert len(ids) == len(set(ids))
references = set(re.findall(r'\b[A-F0-9]{24}\b',project))
assert references == set(ids), 'Dangling project reference'
for path in list(root.glob('App/*.swift'))+list(root.glob('Sources/RetroHubCore/*.swift')):
    assert str(path.relative_to(root)) in project, f'Missing source: {path}'
ET.parse(root/'RetroHub.xcodeproj/xcshareddata/xcschemes/RetroHub.xcscheme')
icons = root/'App/Assets.xcassets/AppIcon.appiconset'
for image in json.loads((icons/'Contents.json').read_text())['images']:
    assert (icons/image['filename']).read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
assert not list(root.rglob('*.entitlements')), 'v1 must not request private entitlements'
tests = (root/'Tests/RetroHubCoreTests/RetroHubCoreTests.swift').read_text()
print(f'PASS: plist, scheme XML, project references, source membership, original PNG icons, no entitlements; {len(re.findall(r"func test",tests))} Swift tests present (not executed).')
