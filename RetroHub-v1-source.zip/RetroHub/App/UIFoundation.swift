import UIKit

struct Theme {
    static let background = UIColor(red: 0.045, green: 0.055, blue: 0.085, alpha: 1)
    static let panel = UIColor(red: 0.09, green: 0.105, blue: 0.15, alpha: 1)
    static let accent = UIColor(red: 0.37, green: 0.95, blue: 0.76, alpha: 1)
    static func color(_ system: GameSystem) -> UIColor {
        let index = GameSystem.allCases.firstIndex(of: system) ?? 0
        return UIColor(hue: CGFloat(index) / 13 + 0.02, saturation: 0.55, brightness: 0.85, alpha: 1)
    }
}

final class LibraryModel {
    private let store: LibraryStore
    private let queue = DispatchQueue(label: "com.retrohub.storage", qos: .userInitiated)
    private(set) var games: [Game]
    let root: URL
    var onChange: (() -> Void)?
    init(store: LibraryStore) { self.store = store; games = store.games; root = store.root }
    func perform<T>(_ work: @escaping (LibraryStore) throws -> T, completion: @escaping (Result<T, Error>) -> Void) {
        queue.async {
            let result = Result { try work(self.store) }; let snapshot = self.store.games
            DispatchQueue.main.async { self.games = snapshot; self.onChange?(); completion(result) }
        }
    }
    func url(_ path: String) -> URL { root.appendingPathComponent(path) }
}

extension UIViewController {
    func message(_ title: String, _ text: String) {
        let alert = UIAlertController(title: title, message: text, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default)); present(alert, animated: true)
    }
    func handle<T>(_ result: Result<T, Error>, success: (T) -> Void = { _ in }) {
        switch result { case .success(let value): success(value); case .failure(let error): message("Couldn’t complete that", error.localizedDescription) }
    }
    func chooseSystem(completion: @escaping (GameSystem) -> Void) {
        let alert = UIAlertController(title: "Choose a system", message: "Used for ambiguous files (ZIP, 7z, BIN, PBP, ISO). Known extensions are detected automatically. Archives are kept intact. For disc games, import a folder with all tracks.", preferredStyle: .actionSheet)
        GameSystem.allCases.forEach { system in alert.addAction(UIAlertAction(title: system.rawValue, style: .default) { _ in completion(system) }) }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.popoverPresentationController?.sourceView = view
        alert.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        present(alert, animated: true)
    }
    func share(_ items: [Any], source: UIView? = nil) {
        let controller = UIActivityViewController(activityItems: items, applicationActivities: nil)
        controller.popoverPresentationController?.sourceView = source ?? view
        controller.popoverPresentationController?.sourceRect = (source ?? view).bounds
        present(controller, animated: true)
    }
}
