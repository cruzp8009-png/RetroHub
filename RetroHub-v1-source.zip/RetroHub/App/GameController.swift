import UIKit
import UniformTypeIdentifiers
import ImageIO

final class GameController: UITableViewController, UIDocumentPickerDelegate {
    private let id: UUID
    private let model: LibraryModel
    private var game: Game? { model.games.first { $0.id == id } }
    init(id: UUID, model: LibraryModel) { self.id = id; self.model = model; super.init(style: .insetGrouped) }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    override func viewDidLoad() {
        super.viewDidLoad(); tableView.backgroundColor = Theme.background; tableView.rowHeight = UITableView.automaticDimension; tableView.estimatedRowHeight = 60
        navigationItem.largeTitleDisplayMode = .never; refresh()
    }
    private func refresh() { title = game?.title; tableView.reloadData() }
    override func numberOfSections(in tableView: UITableView) -> Int { 4 }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { [3, 6, 3, 1][section] }
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? { ["Play & transfer", "Game metadata", "Artwork & emulator", "Storage"][section] }
    override func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        section == 0 ? "External launches open the emulator only. Share or export files, then select the game inside the emulator. Recent activity records successful emulator opens or your manual confirmation." : nil
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil); cell.backgroundColor = Theme.panel
        cell.textLabel?.numberOfLines = 0; cell.detailTextLabel?.numberOfLines = 0; cell.accessoryType = .disclosureIndicator
        guard let game = game else { return cell }
        switch (indexPath.section, indexPath.row) {
        case (0, 0): cell.textLabel?.text = "Open \(selectedEmulator(game).rawValue)"; cell.textLabel?.textColor = Theme.accent
        case (0, 1): cell.textLabel?.text = "Share game / Save to Files"
        case (0, 2): cell.textLabel?.text = "I opened this game manually"
        case (1, 0): cell.textLabel?.text = "Title"; cell.detailTextLabel?.text = game.title
        case (1, 1): cell.textLabel?.text = "System"; cell.detailTextLabel?.text = game.system.rawValue
        case (1, 2): cell.textLabel?.text = game.favorite ? "★ Favorite" : "☆ Add to favorites"
        case (1, 3): cell.textLabel?.text = "Developer"; cell.detailTextLabel?.text = game.developer.isEmpty ? "Add developer" : game.developer
        case (1, 4): cell.textLabel?.text = "Release year"; cell.detailTextLabel?.text = game.year.isEmpty ? "Add year" : game.year
        case (1, 5): cell.textLabel?.text = "Notes"; cell.detailTextLabel?.text = game.notes.isEmpty ? "Add notes" : game.notes
        case (2, 0): cell.textLabel?.text = "Choose cover art from Files"; cell.imageView?.image = game.coverPath.flatMap { UIImage(contentsOfFile: model.url($0).path) }
        case (2, 1): cell.textLabel?.text = "Emulator profile"; cell.detailTextLabel?.text = selectedEmulator(game).rawValue
        case (2, 2): cell.textLabel?.text = "Integration instructions"
        default:
            cell.textLabel?.text = FileManager.default.fileExists(atPath: model.url(game.relativePath).path) ? "Stored locally" : "Game file missing"
            cell.detailTextLabel?.text = game.relativePath; cell.accessoryType = .none
        }
        return cell
    }
    private func selectedEmulator(_ game: Game) -> Emulator {
        if let emulator = game.emulator { return emulator }
        let key = "profile." + game.system.rawValue
        return UserDefaults.standard.string(forKey: key).flatMap(Emulator.init(rawValue:)) ?? (game.system == .psp ? .ppsspp : .retroarch)
    }
    private func update(_ mutation: (inout Game) -> Void) {
        guard var updated = game else { return }; mutation(&updated)
        model.perform({ try $0.update(updated) }) { self.handle($0) { _ in self.refresh() } }
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true); guard let game = game else { return }
        switch (indexPath.section, indexPath.row) {
        case (0, 0): launch(game)
        case (0, 1): shareGame(game)
        case (0, 2): update { $0.lastOpened = Date() }
        case (1, 1): chooseSystem { system in self.update { $0.system = system; if let profile = $0.emulator, !profile.supports(system) { $0.emulator = nil } } }
        case (1, 2): update { $0.favorite.toggle() }
        case (1, let row): edit(row: row, game: game)
        case (2, 0):
            let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.image], asCopy: true)
            picker.delegate = self; present(picker, animated: true)
        case (2, 1):
            let alert = UIAlertController(title: "Emulator profile", message: "RetroArch requires the appropriate core. Compatibility depends on your installed build.", preferredStyle: .actionSheet)
            alert.addAction(UIAlertAction(title: "Use system default", style: .default) { _ in self.update { $0.emulator = nil } })
            Emulator.allCases.filter { $0.supports(game.system) }.forEach { profile in alert.addAction(UIAlertAction(title: profile.rawValue, style: .default) { _ in self.update { $0.emulator = profile } }) }
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel)); alert.popoverPresentationController?.sourceView = view; alert.popoverPresentationController?.sourceRect = tableView.rectForRow(at: indexPath); present(alert, animated: true)
        case (2, 2): message("\(selectedEmulator(game).rawValue) integration", selectedEmulator(game).instructions)
        default: break
        }
    }
    private func edit(row: Int, game: Game) {
        let labels = [0: "Title", 3: "Developer", 4: "Release year", 5: "Notes"]
        guard let label = labels[row] else { return }
        let value = row == 0 ? game.title : row == 3 ? game.developer : row == 4 ? game.year : game.notes
        let alert = UIAlertController(title: label, message: nil, preferredStyle: .alert)
        alert.addTextField { $0.text = value; if row == 4 { $0.keyboardType = .numberPad } }
        alert.addAction(UIAlertAction(title: "Save", style: .default) { _ in
            let text = alert.textFields?.first?.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            guard row != 0 || !text.isEmpty else { self.message("Title required", "Give this game a title."); return }
            self.update { switch row { case 0: $0.title = text; case 3: $0.developer = text; case 4: $0.year = text; default: $0.notes = text } }
        })
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel)); present(alert, animated: true)
    }
    private func launch(_ game: Game) {
        let emulator = selectedEmulator(game)
        guard emulator.supports(game.system) else { message("Choose a compatible profile", "\(emulator.rawValue) does not support this system in RetroHub. Change the game’s emulator profile."); return }
        let url = emulator.launchURL
        guard URLPolicy.isAllowed(url) else { return }
        guard UIApplication.shared.canOpenURL(url) else {
            message("\(emulator.rawValue) isn’t available", "RetroHub could not find a compatible URL handler. Install a build compatible with iOS 14, or open the emulator manually.\n\n" + emulator.instructions); return
        }
        UIApplication.shared.open(url, options: [:]) { success in
            if success { self.update { $0.lastOpened = Date() } }
            else { self.message("Couldn’t open \(emulator.rawValue)", "Your emulator build may not support this URL. Open it manually.\n\n" + emulator.instructions) }
        }
    }
    private func shareGame(_ game: Game) {
        let url = model.url(game.relativePath)
        guard FileManager.default.fileExists(atPath: url.path) else { message("Game file missing", "Metadata import does not include ROM files. Restore the matching Games folder from your backup."); return }
        if ["cue", "bin"].contains(url.pathExtension.lowercased()) {
            message("Disc game transfer", "Export the containing folder using Files → On My iPhone → RetroHub → RetroHub → Games. Copy all tracks together, keeping their names and relative paths.\n\n" + selectedEmulator(game).instructions)
        } else { share([url]) }
    }
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }
        // Picker copies images; downsample before decoding full-sized artwork.
        model.perform({ store in
            let values = try url.resourceValues(forKeys: [.fileSizeKey])
            guard (values.fileSize ?? 0) <= 30 * 1024 * 1024 else { throw LibraryError.artworkTooLarge }
            guard let source = CGImageSourceCreateWithURL(url as CFURL, nil),
                  let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [kCGImageSourceCreateThumbnailFromImageAlways: true, kCGImageSourceThumbnailMaxPixelSize: 800, kCGImageSourceCreateThumbnailWithTransform: true] as CFDictionary),
                  let data = UIImage(cgImage: image).jpegData(compressionQuality: 0.85) else { throw LibraryError.unsupportedFile }
            try store.setCover(data, for: self.id)
        }) { self.handle($0) { _ in self.refresh() } }
    }
}
