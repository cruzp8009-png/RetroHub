import UIKit
import UniformTypeIdentifiers

final class LibraryController: UIViewController, UITableViewDataSource, UITableViewDelegate, UISearchResultsUpdating, UIDocumentPickerDelegate {
    let model: LibraryModel
    private let table = UITableView(frame: .zero, style: .plain)
    private let search = UISearchController(searchResultsController: nil)
    private let summary = UILabel()
    private var system: GameSystem?
    private var mode = 0
    private var pendingSystem = GameSystem.arcade
    private var visible: [Game] = []
    private var importing = false
    init(model: LibraryModel) {
        self.model = model; super.init(nibName: nil, bundle: nil)
        title = "RetroHub"; tabBarItem = UITabBarItem(title: "Library", image: UIImage(systemName: "gamecontroller.fill"), tag: 0)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    override func viewDidLoad() {
        super.viewDidLoad(); view.backgroundColor = Theme.background
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "plus.circle.fill"), style: .plain, target: self, action: #selector(importMenu))
        search.searchResultsUpdater = self; search.obscuresBackgroundDuringPresentation = false
        search.searchBar.placeholder = "Find your next adventure"; navigationItem.searchController = search; definesPresentationContext = true
        let header = UIStackView(); header.axis = .vertical; header.spacing = 14
        summary.font = .monospacedSystemFont(ofSize: 12, weight: .medium); summary.textColor = Theme.accent
        let modes = UISegmentedControl(items: ["All games", "Favorites", "Recent"])
        modes.selectedSegmentIndex = 0; modes.addTarget(self, action: #selector(changeMode(_:)), for: .valueChanged)
        let scroll = UIScrollView(); scroll.showsHorizontalScrollIndicator = false
        let categories = UIStackView(); categories.axis = .horizontal; categories.spacing = 8
        scroll.addSubview(categories); categories.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([categories.leadingAnchor.constraint(equalTo: scroll.contentLayoutGuide.leadingAnchor), categories.trailingAnchor.constraint(equalTo: scroll.contentLayoutGuide.trailingAnchor), categories.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor), categories.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor), categories.heightAnchor.constraint(equalTo: scroll.frameLayoutGuide.heightAnchor), scroll.heightAnchor.constraint(equalToConstant: 40)])
        for (index, name) in (["All systems"] + GameSystem.allCases.map { $0.rawValue }).enumerated() {
            let button = UIButton(type: .system); button.setTitle("  \(name)  ", for: .normal); button.tag = index
            button.backgroundColor = Theme.panel; button.layer.cornerRadius = 12; button.tintColor = Theme.accent
            button.addTarget(self, action: #selector(selectSystem(_:)), for: .touchUpInside); categories.addArrangedSubview(button)
        }
        header.addArrangedSubview(summary); header.addArrangedSubview(modes); header.addArrangedSubview(scroll)
        view.addSubview(header); view.addSubview(table)
        header.translatesAutoresizingMaskIntoConstraints = false; table.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([header.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 12), header.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20), header.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -20), table.topAnchor.constraint(equalTo: header.bottomAnchor, constant: 16), table.leadingAnchor.constraint(equalTo: view.leadingAnchor), table.trailingAnchor.constraint(equalTo: view.trailingAnchor), table.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
        table.backgroundColor = Theme.background; table.separatorStyle = .none; table.rowHeight = 102
        table.dataSource = self; table.delegate = self; table.register(GameCell.self, forCellReuseIdentifier: "game")
        model.onChange = { [weak self] in self?.reload() }; reload()
    }
    override func viewWillAppear(_ animated: Bool) { super.viewWillAppear(animated); reload() }
    func updateSearchResults(for searchController: UISearchController) { reload() }
    @objc private func changeMode(_ sender: UISegmentedControl) { mode = sender.selectedSegmentIndex; reload() }
    @objc private func selectSystem(_ sender: UIButton) { system = sender.tag == 0 ? nil : GameSystem.allCases[sender.tag - 1]; reload() }
    private func reload() {
        let query = search.searchBar.text ?? ""
        visible = model.games.filter { game in
            (system == nil || game.system == system) && (mode != 1 || game.favorite) && (mode != 2 || game.lastOpened != nil) && (query.isEmpty || (game.title + " " + game.notes + " " + game.developer).localizedCaseInsensitiveContains(query))
        }.sorted { mode == 2 ? ($0.lastOpened ?? .distantPast) > ($1.lastOpened ?? .distantPast) : $0.title.localizedStandardCompare($1.title) == .orderedAscending }
        summary.text = "\(model.games.count) GAMES  •  \(system?.rawValue.uppercased() ?? "ALL SYSTEMS")"
        let empty = UILabel(); empty.numberOfLines = 0; empty.textAlignment = .center; empty.textColor = .secondaryLabel
        empty.text = model.games.isEmpty ? "Your collection starts here.\n\nTap + to import games from Files.\nUse games you have the right to use." : "No games match this view."
        table.backgroundView = visible.isEmpty ? empty : nil; table.reloadData()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { visible.count }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "game", for: indexPath) as! GameCell
        cell.configure(visible[indexPath.row], model: model); return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        navigationController?.pushViewController(GameController(id: visible[indexPath.row].id, model: model), animated: true)
    }
    @objc private func importMenu() {
        guard !importing else { return }
        let alert = UIAlertController(title: "Add to your collection", message: "Files are copied into RetroHub. Import folders to preserve multi-file disc games.", preferredStyle: .actionSheet)
        for (title, folder) in [("Import game files", false), ("Import a folder", true)] {
            alert.addAction(UIAlertAction(title: title, style: .default) { _ in
                self.chooseSystem { system in
                    self.pendingSystem = system
                    let picker = UIDocumentPickerViewController(forOpeningContentTypes: folder ? [.folder] : [.data, .item], asCopy: false)
                    picker.allowsMultipleSelection = true; picker.delegate = self; self.present(picker, animated: true)
                }
            })
        }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel)); alert.popoverPresentationController?.barButtonItem = navigationItem.rightBarButtonItem
        present(alert, animated: true)
    }
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) { importFiles(urls, system: pendingSystem) }
    func importExternal(_ url: URL) {
        search.isActive = false
        if let tabs = tabBarController { tabs.selectedIndex = 0 }
        navigationController?.popToRootViewController(animated: false)
        if let system = FileClassifier.classify(url) { importFiles([url], system: system) }
        else { chooseSystem { self.importFiles([url], system: $0) } }
    }
    private func importFiles(_ urls: [URL], system: GameSystem) {
        guard !importing else { message("Import in progress", "Please wait for the current import to finish, then try again."); return }
        importing = true; navigationItem.rightBarButtonItem?.isEnabled = false
        let spinner = UIActivityIndicatorView(style: .medium); spinner.startAnimating()
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: spinner)
        model.perform({ try $0.importItems(urls, ambiguousSystem: system) }) { result in
            self.importing = false; self.navigationItem.rightBarButtonItem?.isEnabled = true; self.navigationItem.leftBarButtonItem = nil
            self.handle(result) { self.message("Ready to play", "Added \($0) games. Files are safely stored in RetroHub.") }
        }
    }
}

final class GameCell: UITableViewCell {
    private let cover = UIImageView(), name = UILabel(), subtitle = UILabel(), star = UILabel()
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier); backgroundColor = Theme.background
        let card = UIView(); card.backgroundColor = Theme.panel; card.layer.cornerRadius = 16
        contentView.addSubview(card); card.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([card.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 20), card.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -20), card.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 5), card.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -5)])
        cover.contentMode = .scaleAspectFill; cover.clipsToBounds = true; cover.layer.cornerRadius = 10
        name.font = .preferredFont(forTextStyle: .headline); name.adjustsFontForContentSizeCategory = true
        subtitle.font = .preferredFont(forTextStyle: .caption1); subtitle.textColor = .secondaryLabel
        let labels = UIStackView(arrangedSubviews: [name, subtitle]); labels.axis = .vertical; labels.spacing = 7
        [cover, labels, star].forEach { card.addSubview($0); $0.translatesAutoresizingMaskIntoConstraints = false }
        NSLayoutConstraint.activate([cover.leadingAnchor.constraint(equalTo: card.leadingAnchor, constant: 10), cover.centerYAnchor.constraint(equalTo: card.centerYAnchor), cover.widthAnchor.constraint(equalToConstant: 64), cover.heightAnchor.constraint(equalToConstant: 72), labels.leadingAnchor.constraint(equalTo: cover.trailingAnchor, constant: 14), labels.centerYAnchor.constraint(equalTo: card.centerYAnchor), labels.trailingAnchor.constraint(equalTo: star.leadingAnchor, constant: -8), star.trailingAnchor.constraint(equalTo: card.trailingAnchor, constant: -16), star.centerYAnchor.constraint(equalTo: card.centerYAnchor), star.widthAnchor.constraint(equalToConstant: 20)])
        star.textColor = Theme.accent; accessibilityTraits = .button
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    func configure(_ game: Game, model: LibraryModel) {
        name.text = game.title; subtitle.text = game.system.rawValue + "  ·  " + game.relativePath.components(separatedBy: ".").last!.uppercased(); star.text = game.favorite ? "★" : "›"
        cover.backgroundColor = Theme.color(game.system).withAlphaComponent(0.22); cover.tintColor = Theme.color(game.system)
        cover.image = game.coverPath.flatMap { UIImage(contentsOfFile: model.url($0).path) } ?? UIImage(systemName: "gamecontroller.fill")
        accessibilityLabel = "\(game.title), \(game.system.rawValue)\(game.favorite ? ", favorite" : "")"
    }
}
