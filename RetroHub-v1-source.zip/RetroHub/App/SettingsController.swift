import UIKit
import UniformTypeIdentifiers

final class SettingsController: UITableViewController, UIDocumentPickerDelegate {
    private let model: LibraryModel
    init(model: LibraryModel) {
        self.model = model; super.init(style: .insetGrouped); title = "Settings"
        tabBarItem = UITabBarItem(title: "Settings", image: UIImage(systemName: "slider.horizontal.3"), tag: 1)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    override func viewDidLoad() { super.viewDidLoad(); tableView.backgroundColor = Theme.background }
    override func numberOfSections(in tableView: UITableView) -> Int { 3 }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { section == 0 ? GameSystem.allCases.count : section == 1 ? 3 : 1 }
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? { ["Default emulator by system", "Local library", "RetroHub"][section] }
    override func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        section == 1 ? "Metadata exports include titles, favorites, notes and relative paths, but no games or cover images. Back up the whole Documents/RetroHub folder in Files to preserve everything. Rescan never removes missing entries." : nil
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil); cell.backgroundColor = Theme.panel; cell.accessoryType = .disclosureIndicator
        if indexPath.section == 0 {
            let system = GameSystem.allCases[indexPath.row]; cell.textLabel?.text = system.rawValue
            cell.detailTextLabel?.text = UserDefaults.standard.string(forKey: "profile." + system.rawValue) ?? (system == .psp ? "PPSSPP" : "RetroArch")
        } else if indexPath.section == 1 { cell.textLabel?.text = ["Export metadata", "Import metadata (merge)", "Rescan app storage"][indexPath.row] }
        else { cell.textLabel?.text = "About & supported formats" }
        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.section == 0 {
            let system = GameSystem.allCases[indexPath.row]
            let alert = UIAlertController(title: system.rawValue, message: "Select an installed emulator compatible with your iOS version.", preferredStyle: .actionSheet)
            Emulator.allCases.filter { $0.supports(system) }.forEach { profile in alert.addAction(UIAlertAction(title: profile.rawValue, style: .default) { _ in UserDefaults.standard.set(profile.rawValue, forKey: "profile." + system.rawValue); tableView.reloadData() }) }
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel)); alert.popoverPresentationController?.sourceView = view; alert.popoverPresentationController?.sourceRect = tableView.rectForRow(at: indexPath); present(alert, animated: true)
        } else if indexPath.section == 2 { navigationController?.pushViewController(AboutController(), animated: true) }
        else {
            switch indexPath.row {
            case 0:
                model.perform({ store -> URL in
                    let url = FileManager.default.temporaryDirectory.appendingPathComponent("RetroHub-Metadata-\(UUID().uuidString).json")
                    try store.exportMetadata().write(to: url, options: .atomic); return url
                }) { self.handle($0) { self.share([$0]) } }
            case 1:
                let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.json], asCopy: true); picker.delegate = self; present(picker, animated: true)
            default:
                chooseSystem { system in self.model.perform({ try $0.scan(ambiguousSystem: system) }) { self.handle($0) { self.message("Scan complete", "Found \($0) new games. Existing metadata was preserved.") } } }
            }
        }
    }
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }
        model.perform({ store in
            let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
            guard size <= 20 * 1024 * 1024 else { throw LibraryError.tooLarge }
            try store.importMetadata(Data(contentsOf: url))
        }) { self.handle($0) { _ in self.message("Metadata merged", "Your existing games were kept. Restore game and cover files separately if they are missing.") } }
    }
}

final class AboutController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad(); title = "About RetroHub"; view.backgroundColor = Theme.background
        let text = UITextView(); text.backgroundColor = Theme.background; text.textColor = .label
        text.font = .preferredFont(forTextStyle: .body); text.adjustsFontForContentSizeCategory = true; text.isEditable = false
        text.textContainerInset = UIEdgeInsets(top: 24, left: 20, bottom: 30, right: 20)
        text.text = "RetroHub 1.0\nYour games. Your device.\n\nA local library and external emulator launcher for iOS 14+. No emulator cores, cloud accounts, analytics, ROMs or BIOS files are included.\n\nSupported files\n\n" + GameSystem.allCases.map { "\($0.rawValue): \($0.extensions.joined(separator: ", "))" }.joined(separator: "\n") + "\n\nBIN, ISO, PBP, ZIP and 7z require a system choice. BIN may be a disc track or Genesis ROM. Import CUE/BIN games as folders with every track. Archives are not extracted; compatibility depends on the emulator. Disc files can contain BIOS or other content—only import files you have rights to use.\n\nEmulator integrations\n\nRetroArch, Delta and PPSSPP register URL schemes in upstream source. RetroHub attempts to open the app, never passes a ROM path or undocumented parameter. Older or repackaged iOS 14 builds may behave differently. Game-specific launching and on-device compatibility have not been verified. Transfer via Files or the share sheet, then select the game in the emulator.\n\nBackup\n\nMetadata export does not include game files or cover images. Copy the complete RetroHub folder from Files for a full backup. Do not uninstall without a backup.\n\nArtwork\n\nThe interface uses original layouts and Apple SF Symbols. Bring your own cover images with appropriate rights. RetroHub source is MIT licensed."
        view.addSubview(text); text.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([text.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor), text.leadingAnchor.constraint(equalTo: view.leadingAnchor), text.trailingAnchor.constraint(equalTo: view.trailingAnchor), text.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
    }
}
