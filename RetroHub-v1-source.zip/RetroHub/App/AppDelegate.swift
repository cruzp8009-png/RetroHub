import UIKit

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    var library: LibraryController?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.overrideUserInterfaceStyle = .dark
        UINavigationBar.appearance().tintColor = Theme.accent
        UITabBar.appearance().tintColor = Theme.accent
        do {
            let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let store = try LibraryStore(root: documents.appendingPathComponent("RetroHub", isDirectory: true))
            let model = LibraryModel(store: store)
            let library = LibraryController(model: model); self.library = library
            let settings = SettingsController(model: model)
            let tabs = UITabBarController()
            tabs.viewControllers = [UINavigationController(rootViewController: library), UINavigationController(rootViewController: settings)]
            window.rootViewController = tabs
        } catch {
            let recovery = UIViewController(); recovery.view.backgroundColor = Theme.background
            let label = UILabel(); label.numberOfLines = 0; label.textColor = .white
            label.text = "RetroHub could not read your library.\n\n\(error.localizedDescription)\n\nYour database and game files have not been reset. Back up Documents/RetroHub using Files before repairing or reinstalling."
            recovery.view.addSubview(label); label.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([label.leadingAnchor.constraint(equalTo: recovery.view.safeAreaLayoutGuide.leadingAnchor, constant: 24), label.trailingAnchor.constraint(equalTo: recovery.view.safeAreaLayoutGuide.trailingAnchor, constant: -24), label.centerYAnchor.constraint(equalTo: recovery.view.centerYAnchor)])
            window.rootViewController = recovery
        }
        self.window = window; window.makeKeyAndVisible()
        return true
    }
    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey: Any] = [:]) -> Bool {
        guard url.isFileURL, library != nil else { return false }
        library?.importExternal(url); return true
    }
}
