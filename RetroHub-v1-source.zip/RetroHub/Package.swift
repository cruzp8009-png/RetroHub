// swift-tools-version:5.5
import PackageDescription
let package = Package(name: "RetroHubCore", platforms: [.iOS(.v14), .macOS(.v11)], products: [.library(name: "RetroHubCore", targets: ["RetroHubCore"])], targets: [.target(name: "RetroHubCore"), .testTarget(name: "RetroHubCoreTests", dependencies: ["RetroHubCore"])])
