# Validation report — 2026-10-09

Environment: Linux, `/workspace`. Neither `swift` nor `xcodebuild` is available. No emulator, simulator or iPhone is attached. No CI job was submitted. No IPA was built.

| Check | Result |
| --- | --- |
| Plist parsing; iOS 14 target; scheme query allowlist; file-sharing keys | PASS |
| Xcode source membership and object reference integrity | PASS |
| Shared Xcode scheme XML | PASS |
| Original app-icon PNG files and catalog references | PASS |
| Deterministic project/plist/icon regeneration (SHA-256 comparison) | PASS |
| Python build-support script compilation | PASS |
| IPA build script shell syntax | PASS |
| Workflow YAML parsing | PASS |
| No entitlements files; no IPA falsely supplied | PASS |
| Build script refuses to build when Xcode is missing | PASS (exit 1 with explicit explanation) |
| Upstream iOS URL-scheme registrations | VERIFIED in source; see INTEGRATIONS.md |
| Swift XCTest suite (8 cases) | NOT RUN — compiler unavailable |
| Device archive / simulator compilation | NOT RUN — Xcode unavailable |
| App-only emulator launch behavior | UNVERIFIED on installed versions |
| Game-specific launch | NOT IMPLEMENTED; manual transfer fallback |
| On-device UI, persistence and installation | NOT TESTED |

Structural checks do not establish Swift compilation or runtime correctness. The macOS CI workflow runs `swift test` before packaging and fails on a compiler/test error. Logs and an IPA are only produced by that workflow after the relevant steps succeed.

## Automated XCTest coverage

1. Classification across supported systems, case handling, ambiguous and unsupported extensions.
2. Persistence of game metadata, recent dates, favorites, profile and cover path across reopening; scans avoid duplicates.
3. Folder import preserves CUE/BIN tracks and excludes symlinks.
4. Metadata merge preserves unrelated games, uses stored paths and keeps local IDs; export round-trips.
5. Traversal, duplicate metadata and future schema rejection leave the database unchanged.
6. Corrupt database is never silently reset.
7. Failed import rolls back its new storage batch.
8. Exact registered URL allowlist rejects paths, queries, arbitrary schemes and untrusted destinations.

Fixtures are synthetic text/binary data, never ROMs or BIOS content. Run `swift test` on macOS to obtain actual test results.

## Device acceptance checks still needed

Using the existing installer and emulator versions, install a successfully built IPA. Confirm Files and Open In imports, folder-based disc tracks, search/favorites, cover editing, relaunch persistence, metadata merge/export, rescan and unavailable-emulator messages. Test each installed emulator's bare app-open attempt and the Files/share fallback. Verify the dark layout on iPhone 11 Pro, large text, and iPad popovers if used. None of these checks has been claimed as performed.
