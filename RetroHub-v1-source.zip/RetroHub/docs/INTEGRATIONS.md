# External emulator integrations

Source registration was verified on 2026-10-09. **No installed emulator or device has been tested.** An upstream registration establishes the scheme name, not the behavior of every old or repackaged build. Bare URLs below are conservative app-open attempts, guarded with `canOpenURL` and an `open` completion handler. No game launch, import command, ROM path or other undocumented parameter is sent.

| Profile | Exact allowed URL | Source | Limits |
| --- | --- | --- | --- |
| RetroArch | `retroarch://` | [iOS Info.plist](https://github.com/libretro/RetroArch/blob/cb1b37a8c78bb40b4f47d96120d4406f265bd354/pkg/apple/iOS/Info.plist), `CFBundleURLTypes` | Build and installed cores determine supported systems. Older iOS9 packaging does not register this scheme. |
| Delta | `delta://` | [Info.plist](https://github.com/rileytestut/Delta/blob/c1d3d068e019e6493eed45654569db3cc5beb86a/Delta/Supporting%20Files/Info.plist), Delta `CFBundleURLSchemes` | Compatible builds support NES, SNES, GB/GBC/GBA, N64 and DS. Modern upstream builds may require newer iOS. No game identifier or import parameter is used. |
| PPSSPP | `ppsspp://` | [iOS Info.plist](https://github.com/hrydgard/ppsspp/blob/0ac523c4b56d91b1db264858f719fcb1e1dffe56/ios/PPSSPP-Info.plist), `CFBundleURLSchemes` | PSP only. Registration verified at the linked upstream commit. No per-game command is used. |

If a scheme is absent or launch fails, RetroHub explains how to open the emulator manually. iOS cannot reliably distinguish “not installed” from a build that lacks a supported handler; the message says the integration is unavailable rather than asserting the app is absent.

Use the game detail share action to offer a ROM to compatible installed apps or save it to Files. Share-sheet availability is emulator-dependent. For CUE/BIN games, copy the complete containing folder through Files to preserve tracks. Emulator sandboxes cannot read RetroHub's private paths directly. Nothing changes your jailbreak, emulator configuration, cores or system files.

Recent activity means a successful **app-open request**, or the user choosing “I opened this game manually.” It is not proof that a game ran.

To recheck scheme registrations, inspect the upstream iOS `CFBundleURLTypes` and handler source. Do not expand `URLPolicy.allowed` based on guesses. Installation compatibility with iOS 14.0.1 is the user's existing emulator build's responsibility; RetroHub does not install emulators.
