import XCTest
@testable import RetroHubCore

final class RetroHubCoreTests: XCTestCase {
    private var root: URL!
    override func setUpWithError() throws {
        root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
    }
    override func tearDownWithError() throws { try FileManager.default.removeItem(at: root) }
    private func fixture(_ name: String, in directory: URL? = nil) throws -> URL {
        let url = (directory ?? root).appendingPathComponent(name)
        try Data("synthetic test fixture; not a ROM".utf8).write(to: url); return url
    }
    func testClassificationAllSystemsAndCase() {
        let cases: [(String, GameSystem)] = [("NES", .nes), ("sfc", .snes), ("gb", .gb), ("gbc", .gbc), ("gba", .gba), ("z64", .n64), ("nds", .ds), ("cue", .ps1), ("cso", .psp), ("md", .genesis)]
        for (ext, system) in cases { XCTAssertEqual(FileClassifier.classify(URL(fileURLWithPath: "/test.\(ext)")), system) }
        for ext in ["zip", "7z", "bin", "pbp", "iso"] {
            let url = URL(fileURLWithPath: "/test.\(ext)")
            XCTAssertNil(FileClassifier.classify(url)); XCTAssertTrue(FileClassifier.isSupported(url))
        }
        XCTAssertFalse(FileClassifier.isSupported(URL(fileURLWithPath: "/readme.txt")))
    }
    func testPersistenceOfGamesMetadataAndArtwork() throws {
        let storage = root.appendingPathComponent("storage")
        let store = try LibraryStore(root: storage)
        XCTAssertEqual(try store.importItems([fixture("demo.gba")], ambiguousSystem: .arcade), 1)
        var game = try XCTUnwrap(store.games.first)
        game.favorite = true; game.notes = "My save"; game.year = "2001"; game.developer = "Example"; game.lastOpened = Date(timeIntervalSince1970: 42); game.emulator = .delta
        try store.update(game); try store.setCover(Data([1, 2, 3]), for: game.id)
        let reloaded = try LibraryStore(root: storage)
        XCTAssertEqual(reloaded.games, store.games)
        XCTAssertTrue(FileManager.default.fileExists(atPath: try reloaded.fileURL(for: reloaded.games[0].relativePath).path))
        XCTAssertEqual(try reloaded.scan(ambiguousSystem: .arcade), 0)
    }
    func testFolderImportPreservesCueTracksAndIgnoresSymlinks() throws {
        let folder = root.appendingPathComponent("disc")
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        _ = try fixture("game.cue", in: folder); _ = try fixture("track.bin", in: folder)
        try FileManager.default.createSymbolicLink(at: folder.appendingPathComponent("link.gba"), withDestinationURL: fixture("external.gba"))
        let store = try LibraryStore(root: root.appendingPathComponent("storage"))
        XCTAssertEqual(try store.importItems([folder], ambiguousSystem: .ps1), 1)
        let game = try XCTUnwrap(store.games.first)
        XCTAssertEqual(game.system, .ps1)
        let destination = try store.fileURL(for: game.relativePath).deletingLastPathComponent()
        XCTAssertTrue(FileManager.default.fileExists(atPath: destination.appendingPathComponent("track.bin").path))
        XCTAssertFalse(FileManager.default.fileExists(atPath: destination.appendingPathComponent("link.gba").path))
    }
    func testMergeKeepsExistingGamesAndUsesPaths() throws {
        let store = try LibraryStore(root: root.appendingPathComponent("storage"))
        _ = try store.importItems([fixture("one.nes"), fixture("two.gb")], ambiguousSystem: .arcade)
        var changed = store.games[0]; changed.id = UUID(); changed.title = "Edited"; changed.favorite = true
        let originalID = store.games[0].id
        let data = try JSONEncoder().encode(LibrarySnapshot(games: [changed]))
        try store.importMetadata(data)
        XCTAssertEqual(store.games.count, 2); XCTAssertEqual(store.games[0].id, originalID); XCTAssertTrue(store.games[0].favorite)
        let exported = try store.exportMetadata()
        XCTAssertEqual(try JSONDecoder().decode(LibrarySnapshot.self, from: exported).games, store.games)
    }
    func testRejectsTraversalDuplicateAndFutureSchemaWithoutChangingDatabase() throws {
        let storage = root.appendingPathComponent("storage"), store = try LibraryStore(root: root.appendingPathComponent("storage"))
        _ = try store.importItems([fixture("one.nes")], ambiguousSystem: .nes)
        let original = try Data(contentsOf: storage.appendingPathComponent("library.json"))
        var unsafe = store.games[0]; unsafe.relativePath = "Games/../../outside.nes"
        XCTAssertThrowsError(try store.importMetadata(JSONEncoder().encode(LibrarySnapshot(games: [unsafe]))))
        XCTAssertThrowsError(try store.importMetadata(JSONEncoder().encode(LibrarySnapshot(games: [store.games[0], store.games[0]]))))
        XCTAssertThrowsError(try store.importMetadata(Data("{\"version\":2,\"unknown\":true}".utf8)))
        XCTAssertEqual(try Data(contentsOf: storage.appendingPathComponent("library.json")), original)
        XCTAssertThrowsError(try store.fileURL(for: "/etc/passwd"))
        XCTAssertThrowsError(try store.fileURL(for: "Games/./one.nes"))
    }
    func testCorruptDatabaseIsNeverReset() throws {
        let storage = root.appendingPathComponent("storage")
        _ = try LibraryStore(root: storage)
        let corrupt = Data("broken".utf8), database = storage.appendingPathComponent("library.json")
        try corrupt.write(to: database)
        XCTAssertThrowsError(try LibraryStore(root: storage))
        XCTAssertEqual(try Data(contentsOf: database), corrupt)
    }
    func testFailedImportRollsBackNewBatch() throws {
        let store = try LibraryStore(root: root.appendingPathComponent("storage"))
        XCTAssertThrowsError(try store.importItems([fixture("unsupported.txt")], ambiguousSystem: .arcade))
        XCTAssertTrue(store.games.isEmpty)
        XCTAssertTrue(try FileManager.default.contentsOfDirectory(atPath: store.root.appendingPathComponent("Games").path).isEmpty)
    }
    func testURLValidationOnlyAllowsExactRegisteredAppOpenURLs() {
        for emulator in Emulator.allCases { XCTAssertTrue(URLPolicy.isAllowed(emulator.launchURL)) }
        for value in ["https://example.com", "file:///tmp/game.nes", "delta://game/123", "delta://?rom=test", "ppsspp://load", "retroarch://evil", "retroarchs://", "DELTA://", "delta://user@host"] {
            XCTAssertFalse(URLPolicy.isAllowed(URL(string: value)!))
        }
        XCTAssertFalse(Emulator.ppsspp.supports(.nes)); XCTAssertFalse(Emulator.delta.supports(.ps1))
    }
}
