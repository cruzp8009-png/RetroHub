import Foundation

/// Use from one serial queue. Atomic JSON is the v1 local database: small, portable, no dependencies.
public final class LibraryStore {
    public let root: URL
    public private(set) var games: [Game] = []
    private let fm = FileManager.default
    private var database: URL { root.appendingPathComponent("library.json") }
    public init(root: URL) throws {
        self.root = root
        try fm.createDirectory(at: root, withIntermediateDirectories: true)
        for directory in ["Games", "Covers"] {
            try fm.createDirectory(at: root.appendingPathComponent(directory), withIntermediateDirectories: true)
        }
        if fm.fileExists(atPath: database.path) { games = try decode(Data(contentsOf: database)).games }
    }
    public func fileURL(for path: String) throws -> URL {
        guard !path.isEmpty, !path.hasPrefix("/"), !path.contains("\\"),
              !path.split(separator: "/", omittingEmptySubsequences: false).contains(where: { $0 == ".." || $0 == "." || $0.isEmpty }),
              path.hasPrefix("Games/") || path.hasPrefix("Covers/") else { throw LibraryError.unsafePath }
        let url = root.appendingPathComponent(path).standardizedFileURL
        let resolved = url.resolvingSymlinksInPath().path
        guard resolved.hasPrefix(root.resolvingSymlinksInPath().path + "/") else { throw LibraryError.unsafePath }
        return url
    }
    private func decode(_ data: Data) throws -> LibrarySnapshot {
        guard data.count <= 20 * 1024 * 1024 else { throw LibraryError.tooLarge }
        // Read version first so a newer schema is never mistaken for corruption or reset.
        struct Header: Decodable { let version: Int }
        let header = try JSONDecoder().decode(Header.self, from: data)
        guard header.version == 1 else { throw LibraryError.unsupportedVersion(header.version) }
        let snapshot = try JSONDecoder().decode(LibrarySnapshot.self, from: data)
        guard Set(snapshot.games.map { $0.id }).count == snapshot.games.count,
              Set(snapshot.games.map { $0.relativePath }).count == snapshot.games.count else { throw LibraryError.invalidMetadata }
        for game in snapshot.games {
            guard !game.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                  game.relativePath.hasPrefix("Games/") else { throw LibraryError.invalidMetadata }
            _ = try fileURL(for: game.relativePath)
            if let cover = game.coverPath {
                guard cover.hasPrefix("Covers/") else { throw LibraryError.unsafePath }
                _ = try fileURL(for: cover)
            }
        }
        return snapshot
    }
    private func commit(_ updated: [Game]) throws {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        let data = try encoder.encode(LibrarySnapshot(games: updated))
        _ = try decode(data)
        try data.write(to: database, options: .atomic)
        games = updated
    }
    public func update(_ game: Game) throws {
        guard let index = games.firstIndex(where: { $0.id == game.id }) else { throw LibraryError.invalidMetadata }
        var updated = games; updated[index] = game; try commit(updated)
    }
    public func exportMetadata() throws -> Data {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        return try encoder.encode(LibrarySnapshot(games: games))
    }
    /// Merge by storage path. Does not delete games or copy ROMs from the metadata file.
    public func importMetadata(_ data: Data) throws {
        let incoming = try decode(data)
        var merged = games
        for var game in incoming.games {
            if let index = merged.firstIndex(where: { $0.relativePath == game.relativePath }) {
                game.id = merged[index].id; merged[index] = game
            } else {
                if merged.contains(where: { $0.id == game.id }) { game.id = UUID() }
                merged.append(game)
            }
        }
        try commit(merged)
    }
    /// Preserve entire imported folders so CUE tracks and companion files keep relative paths.
    /// Symlinks and hidden files are never followed. Archives are copied, never extracted.
    public func importItems(_ urls: [URL], ambiguousSystem: GameSystem) throws -> Int {
        var count = 0
        for source in urls {
            let scoped = source.startAccessingSecurityScopedResource()
            defer { if scoped { source.stopAccessingSecurityScopedResource() } }
            let values = try source.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            guard values.isSymbolicLink != true else { throw LibraryError.unsafePath }
            let batch = root.appendingPathComponent("Games/" + UUID().uuidString, isDirectory: true)
            try fm.createDirectory(at: batch, withIntermediateDirectories: true)
            do {
                let destination = batch.appendingPathComponent(source.lastPathComponent)
                // Coordinate reads so iCloud and third-party Files providers can materialize content.
                var coordinationError: NSError?
                var copyError: Error?
                NSFileCoordinator(filePresenter: nil).coordinate(readingItemAt: source, options: [], error: &coordinationError) { readable in
                    do {
                        if values.isDirectory == true {
                            try self.copyDirectory(readable, to: destination)
                        } else {
                            guard FileClassifier.isSupported(readable) || FileClassifier.isAuxiliary(readable) else { throw LibraryError.unsupportedFile }
                            try self.fm.copyItem(at: readable, to: destination)
                        }
                    } catch { copyError = error }
                }
                if let error = coordinationError { throw error }
                if let error = copyError { throw error }
                let found = try discover(in: batch, ambiguousSystem: ambiguousSystem)
                guard !found.isEmpty else { throw LibraryError.unsupportedFile }
                try commit(games + found); count += found.count
            } catch {
                // Roll back only this newly created batch; previous imports remain intact.
                try? fm.removeItem(at: batch); throw error
            }
        }
        return count
    }
    private func copyDirectory(_ source: URL, to destination: URL) throws {
        try fm.createDirectory(at: destination, withIntermediateDirectories: true)
        for child in try fm.contentsOfDirectory(at: source, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey], options: [.skipsHiddenFiles]) {
            let values = try child.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            guard values.isSymbolicLink != true else { continue }
            let target = destination.appendingPathComponent(child.lastPathComponent)
            if values.isDirectory == true { try copyDirectory(child, to: target) }
            else { try fm.copyItem(at: child, to: target) }
        }
    }
    private func discover(in directory: URL, ambiguousSystem: GameSystem) throws -> [Game] {
        guard let enumerator = fm.enumerator(at: directory, includingPropertiesForKeys: [.isRegularFileKey, .isSymbolicLinkKey], options: [.skipsHiddenFiles]) else { return [] }
        var candidates: [URL] = []
        for case let url as URL in enumerator {
            let values = try url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey])
            if values.isSymbolicLink == true { enumerator.skipDescendants(); continue }
            if values.isRegularFile == true && FileClassifier.isSupported(url) { candidates.append(url) }
        }
        // A CUE directory's BINs are tracks, not independent library entries.
        let cueDirectories = Set(candidates.filter { $0.pathExtension.lowercased() == "cue" }.map { $0.deletingLastPathComponent().path })
        return candidates.filter { !($0.pathExtension.lowercased() == "bin" && cueDirectories.contains($0.deletingLastPathComponent().path)) }.map {
            Game(title: $0.deletingPathExtension().lastPathComponent,
                 system: FileClassifier.classify($0) ?? ambiguousSystem,
                 relativePath: String($0.path.dropFirst(root.path.count + 1)))
        }
    }
    public func scan(ambiguousSystem: GameSystem) throws -> Int {
        let discovered = try discover(in: root.appendingPathComponent("Games"), ambiguousSystem: ambiguousSystem)
        let paths = Set(games.map { $0.relativePath })
        let newGames = discovered.filter { !paths.contains($0.relativePath) }
        try commit(games + newGames); return newGames.count
    }
    public func setCover(_ data: Data, for id: UUID) throws {
        guard var game = games.first(where: { $0.id == id }) else { throw LibraryError.invalidMetadata }
        let path = "Covers/\(id.uuidString)-\(UUID().uuidString).jpg"
        let url = try fileURL(for: path)
        try data.write(to: url, options: .atomic)
        game.coverPath = path
        do { try update(game) } catch { try? fm.removeItem(at: url); throw error }
    }
}
