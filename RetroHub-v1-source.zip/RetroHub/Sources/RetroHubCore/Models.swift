import Foundation

public enum GameSystem: String, Codable, CaseIterable {
    case nes = "NES", snes = "SNES", gb = "GB", gbc = "GBC", gba = "GBA", n64 = "N64"
    case ds = "Nintendo DS", ps1 = "PS1", psp = "PSP", genesis = "Sega Genesis", arcade = "Arcade"
    public var extensions: [String] {
        switch self {
        case .nes: return ["nes"]
        case .snes: return ["sfc", "smc"]
        case .gb: return ["gb"]
        case .gbc: return ["gbc"]
        case .gba: return ["gba"]
        case .n64: return ["n64", "z64", "v64"]
        case .ds: return ["nds"]
        case .ps1: return ["cue", "chd", "pbp"]
        case .psp: return ["iso", "cso"]
        case .genesis: return ["md", "gen", "smd"]
        case .arcade: return ["zip", "7z"]
        }
    }
}

public enum FileClassifier {
    /// ZIP/7z and BIN/PBP are ambiguous; callers must ask for a system.
    public static func classify(_ url: URL) -> GameSystem? {
        let ext = url.pathExtension.lowercased()
        guard !["zip", "7z", "bin", "pbp", "iso"].contains(ext) else { return nil }
        return GameSystem.allCases.first { $0.extensions.contains(ext) }
    }
    public static func isSupported(_ url: URL) -> Bool {
        GameSystem.allCases.flatMap { $0.extensions }.contains(url.pathExtension.lowercased()) || url.pathExtension.lowercased() == "bin"
    }
    public static func isAuxiliary(_ url: URL) -> Bool {
        ["bin", "img", "sub", "ccd", "wav", "ape", "flac"].contains(url.pathExtension.lowercased())
    }
}

public enum Emulator: String, Codable, CaseIterable {
    case retroarch = "RetroArch", delta = "Delta", ppsspp = "PPSSPP"
    public var launchURL: URL { URL(string: URLPolicy.allowed[rawValue]!)! }
    public func supports(_ system: GameSystem) -> Bool {
        switch self {
        case .retroarch: return true // Core availability is installation-dependent.
        case .delta: return [.nes, .snes, .gb, .gbc, .gba, .n64, .ds].contains(system)
        case .ppsspp: return system == .psp
        }
    }
    public var instructions: String {
        switch self {
        case .retroarch: return "Open RetroArch, install a compatible core if needed, then use Load Content. Share the game or folder files from RetroHub to Files and place them in RetroArch's accessible storage. BIOS/core requirements depend on the system."
        case .delta: return "Share this game to Delta if it appears in the share sheet, or save it to Files and use Delta's + → Files importer. Your Delta build must support this iOS version and game system."
        case .ppsspp: return "Save the game to Files, then import it into PPSSPP or copy it into PPSSPP's accessible game folder. Open PPSSPP and select the game."
        }
    }
}

public enum URLPolicy {
    // Verified registrations in upstream iOS Info.plist files; see docs/INTEGRATIONS.md.
    public static let allowed = ["RetroArch": "retroarch://", "Delta": "delta://", "PPSSPP": "ppsspp://"]
    public static func isAllowed(_ url: URL) -> Bool { allowed.values.contains(url.absoluteString) }
}

public struct Game: Codable, Identifiable, Equatable {
    public var id: UUID
    public var title: String
    public var system: GameSystem
    public var relativePath: String
    public var favorite: Bool
    public var lastOpened: Date?
    public var notes: String
    public var developer: String
    public var year: String
    public var coverPath: String?
    public var emulator: Emulator?
    public init(id: UUID = UUID(), title: String, system: GameSystem, relativePath: String) {
        self.id = id; self.title = title; self.system = system; self.relativePath = relativePath
        favorite = false; notes = ""; developer = ""; year = ""
    }
}

public struct LibrarySnapshot: Codable {
    public var version: Int = 1
    public var games: [Game]
    public init(games: [Game]) { self.games = games }
}

public enum LibraryError: LocalizedError {
    case unsupportedVersion(Int), unsafePath, invalidMetadata, unsupportedFile, tooLarge, artworkTooLarge
    public var errorDescription: String? {
        switch self {
        case .unsupportedVersion(let n): return "Library format \(n) is newer than this app. Your files have been preserved."
        case .unsafePath: return "This metadata contains an unsafe storage path."
        case .invalidMetadata: return "The metadata contains duplicate games or invalid fields."
        case .unsupportedFile: return "No supported game files were found."
        case .tooLarge: return "The metadata file exceeds the 20 MB limit."
        case .artworkTooLarge: return "Choose cover art smaller than 30 MB."
        }
    }
}
